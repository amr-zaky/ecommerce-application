package com.example.ecommerce;

public class Appconfig {

    public  static  String add_pro="http://192.168.43.4/ecommerce/readall.php";
    public  static  String del_pro="http://192.168.43.4/ecommerce/delete.php";
    public  static  String added_pro="http://192.168.43.4/ecommerce/add.php";
}

