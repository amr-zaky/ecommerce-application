package com.example.ecommerce;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.Nullable;

import java.util.Date;

public class DB extends SQLiteOpenHelper {
    private static String databaseName = "ecommerceDB";
    private static final int version = 6;
    SQLiteDatabase ecommerceDB;
    public DB(Context context) {
        super(context, databaseName, null, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table customers(custID integer primary key autoincrement, custName text not null, " +
                "username text not null, password text not null, gender text not null, birthdate text not null, job text not null)");

        db.execSQL("create table orders(ordID integer primary key autoincrement, ordDate text not null, address text not null, " +
                "custID integer not null, FOREIGN KEY(custID) REFERENCES customers (custID))");

        db.execSQL("create table orderDetails(quantity integer not null, ordID integer, proID integer, " +
                "FOREIGN KEY(ordID) REFERENCES orders (ordID), FOREIGN KEY(proID) REFERENCES products (proID), primary key(ordID, proID))");

        db.execSQL("create table categories(catID integer primary key autoincrement, catName text not null)");

        db.execSQL("create table products(proID integer primary key autoincrement, proName text not null, price real not null, quantity integer, " +
                "catID integer, FOREIGN KEY(catID) REFERENCES categories (catID))");

        db.execSQL("create table card (proName text not null, price integer not null,Quantity integer not null, username text" +
                " ,FOREIGN KEY (username) References  customers (username))");

        db.execSQL("INSERT INTO categories (catName) VALUES ('Mobile Phones')");
        db.execSQL("INSERT INTO categories (catName) VALUES ('Electronics')");
        db.execSQL("INSERT INTO categories (catName) VALUES ('Fashions')");


        db.execSQL("INSERT INTO products (proName, price, quantity, catID) VALUES ('Galaxy S7', 4500, 5, 1)");
        db.execSQL("INSERT INTO products (proName, price, quantity, catID) VALUES ('Galaxy Note7', 4500, 4, 1)");
        db.execSQL("INSERT INTO products (proName, price, quantity, catID) VALUES ('S9', 4500, 5, 1)");
        db.execSQL("INSERT INTO products (proName, price, quantity, catID) VALUES ('Galaxy Note5', 4500, 7, 1)");
        db.execSQL("INSERT INTO products (proName, price, quantity, catID) VALUES ('Galaxy Grand', 4500, 12, 1)");

        db.execSQL("INSERT INTO products (proName, price, quantity, catID) VALUES ('Lenovo Y5', 1651, 12, 2)");
        db.execSQL("INSERT INTO products (proName, price, quantity, catID) VALUES ('DELL E50', 654165, 7, 2)");
        db.execSQL("INSERT INTO products (proName, price, quantity, catID) VALUES ('Toshiba A5', 65132, 2, 2)");
        db.execSQL("INSERT INTO products (proName, price, quantity, catID) VALUES ('HP 15', 54615, 14, 2)");
        db.execSQL("INSERT INTO products (proName, price, quantity, catID) VALUES ('Sony Z5', 52554, 5, 2)");

        db.execSQL("INSERT INTO products (proName, price, quantity, catID) VALUES ('T-shirt Polo', 20, 5, 3)");
        db.execSQL("INSERT INTO products (proName, price, quantity, catID) VALUES ('Shirt Polo', 17, 5, 3)");
        db.execSQL("INSERT INTO products (proName, price, quantity, catID) VALUES ('Supreme Jacket', 16, 5, 3)");
        db.execSQL("INSERT INTO products (proName, price, quantity, catID) VALUES ('Polo Jacket', 147, 5, 3)");
        db.execSQL("INSERT INTO products (proName, price, quantity, catID) VALUES ('T-shirt Supreme', 136, 5, 3)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS customers");
        db.execSQL("DROP TABLE IF EXISTS orders");
        db.execSQL("DROP TABLE IF EXISTS orderDetails");
        db.execSQL("DROP TABLE IF EXISTS products");
        db.execSQL("DROP TABLE IF EXISTS categories");

        onCreate(db);
    }

    public Cursor getQuantityForCurrentCustomer(Integer ordID)
    {
        ecommerceDB=getReadableDatabase();
        /*, products.price, orderDetails.price */
        Cursor cursor = ecommerceDB.rawQuery("SELECT orderDetails.quantity " +
                "FROM " +
                "products " +
                "INNER JOIN orderDetails ON orderDetails.proID = products.proID " +
                "INNER JOIN orders ON orders.ordID = orderDetails.ordID " +
                "WHERE " +
                "orders.ordID = " + ordID, null);
        if (cursor !=null)
            cursor.moveToFirst();
        return cursor;
    }

    public Cursor fetchAllOrders(Integer custID)
    {
        ecommerceDB=getReadableDatabase();
        Cursor cursor = ecommerceDB.rawQuery("SELECT * " +
                "FROM " +
                    "products " +
                "INNER JOIN orderDetails ON orderDetails.proID = products.proID " +
                "INNER JOIN orders ON orders.ordID = orderDetails.ordID " +
                "WHERE " +
                "orders.custID = " + custID, null);
        if (cursor !=null)
            cursor.moveToFirst();
        return cursor;
    }

    public void deleteOrder(Integer ordID)
    {
        ecommerceDB = getWritableDatabase();
        ecommerceDB.delete("orders", "ordID = " + ordID, null);
        ecommerceDB.close();
    }

    public void updateQuantity(Integer newQuantity, Integer ordID)
    {
        ecommerceDB = getWritableDatabase();
        ContentValues row = new ContentValues();
        row.put("quantity", newQuantity);
        ecommerceDB.update("orderDetails", row,"ordID like ?", new String[]{ordID.toString()});
        ecommerceDB.close();
    }

    public Cursor getOrderID(String proName)
    {
        ecommerceDB = getReadableDatabase();
        Cursor cursor = ecommerceDB.rawQuery("SELECT orders.ordID " +
                "FROM " +
                "products " +
                "INNER JOIN orderDetails ON orderDetails.proID = products.proID " +
                "INNER JOIN orders ON orders.ordID = orderDetails.ordID " +
                "WHERE " +
                "products.proName = '" + proName + "'", null);
        if (cursor !=null)
            cursor.moveToFirst();
        return cursor;
    }

    public long createNewCustomer(String name, String username, String password, String gender, String birthdate, String job)
    {
        ContentValues row = new ContentValues();
        row.put("custName", name);
        row.put("username", username);
        row.put("password", password);
        row.put("gender", gender);
        row.put("birthdate", birthdate);
        row.put("job", job);
        ecommerceDB = getWritableDatabase();
        return ecommerceDB.insert("customers", null, row);
    }
/*
    public Cursor fetchAllCustomers()
    {
        ecommerceDB=getReadableDatabase();
        Cursor cursor=ecommerceDB.rawQuery("select * from customers", null);
        if (cursor !=null)
            ((Cursor) cursor).moveToFirst();
        return cursor;
    }*/

    public boolean login(String username, String password){
        ecommerceDB=getWritableDatabase();
        Cursor cursor = ecommerceDB.rawQuery("select * from customers where username = '"+ username +"' and password = '"+ password+"'", null);//raw query always holds rawQuery(String Query,select args)

        if(cursor!=null && cursor.getCount()>0){
            cursor.close();
            return true;
        }
        else{
            cursor.close();
            return false;
        }
    }

    public Integer saveId(String username, String password){
        ecommerceDB=getWritableDatabase();
        Cursor cursor = ecommerceDB.rawQuery("select custID from customers where username = '"+ username +"' and password = '"+ password+"'", null);//raw query always holds rawQuery(String Query,select args)
        if (cursor !=null)
            ((Cursor) cursor).moveToFirst();
        return cursor.getInt(0);
    }

    public Cursor categories()
    {
        ecommerceDB=getReadableDatabase();
        Cursor cursor=ecommerceDB.rawQuery("select * from categories", null);
        if (cursor !=null)
            ((Cursor) cursor).moveToFirst();
        return cursor;
    }

    public Cursor fetchMobiles()
    {
        ecommerceDB=getReadableDatabase();
        Cursor cursor=ecommerceDB.rawQuery("select * from products where catID like 1", null);
        if (cursor !=null)
            cursor.moveToFirst();
        return cursor;
    }

    public Cursor fetchElectronics()
    {
        ecommerceDB=getReadableDatabase();
        Cursor cursor=ecommerceDB.rawQuery("select * from products where catID = 2", null);
        if (cursor !=null)
            ((Cursor) cursor).moveToFirst();
        return cursor;
    }

    public Cursor fetchFashions()
    {
        ecommerceDB=getReadableDatabase();
        Cursor cursor=ecommerceDB.rawQuery("select * from products where catID = 3", null);
        if (cursor !=null)
            ((Cursor) cursor).moveToFirst();
        return cursor;
    }

    public Cursor getPrice(String name)
    {
        ecommerceDB=getReadableDatabase();
        Cursor cursor=ecommerceDB.rawQuery("select * from products where proName like '" + name + "'", null);
        if (cursor !=null)
            ((Cursor) cursor).moveToFirst();
        return cursor;
    }

    public Cursor searchInProducts(String name)
    {
        ecommerceDB = getReadableDatabase();
        Cursor cursor = ecommerceDB.rawQuery("SELECT * FROM products WHERE proName LIKE '%" + name + "%'", null);
        if(cursor != null)
            cursor.moveToFirst();
        ecommerceDB.close();
        return cursor;
    }

    public void changePassword(String email, String newPassword)
    {
        ecommerceDB = getWritableDatabase();
        ContentValues row = new ContentValues();
        row.put("password", newPassword);
        ecommerceDB.update("customers", row,"username like ?", new String[]{email});
        ecommerceDB.close();
    }

    public boolean whatsYourJob(String mail, String job){
        ecommerceDB=getWritableDatabase();
        Cursor cursor = ecommerceDB.rawQuery("select * from customers where username = '"+ mail +"' and job = '"+ job+"'", null);//raw query always holds rawQuery(String Query,select args)

        if(cursor!=null && cursor.getCount()>0){
            cursor.close();
            return true;
        }
        else{
            cursor.close();
            return false;
        }
    }
/*
    public Cursor getproductName(String proName)
    {
        ecommerceDB = getReadableDatabase();
        Cursor cursor = ecommerceDB.rawQuery("select proName from products where proName = " + proName,null);
        if(cursor.getCount()!=0)
        {
            cursor.moveToFirst();
            return  cursor;
        }
        return  cursor;
    }*/

    public long makeOrder(String ordDate, String address, Integer custID)
    {
        ContentValues row = new ContentValues();
        row.put("ordDate", ordDate);
        row.put("address", address);
        row.put("custID", custID);
        ecommerceDB = getWritableDatabase();
        return ecommerceDB.insert("orders", null, row);
    }

    public long makeOrderDetails(Integer ordID, Integer proID, Integer quantity)
    {
        ContentValues row = new ContentValues();
        row.put("ordID", ordID);
        row.put("proID", proID);
        row.put("quantity", quantity);
        ecommerceDB = getWritableDatabase();
        return ecommerceDB.insert("orderDetails", null, row);
    }

    public Cursor fetchAllOrderDetails()
    {
        ecommerceDB=getReadableDatabase();
        Cursor cursor=ecommerceDB.rawQuery("select * from orderDetails", null);
        if (cursor !=null)
            ((Cursor) cursor).moveToFirst();
        return cursor;
    }

    public Cursor getOrderId(String ordDate, String address, Integer custID)
    {
        ecommerceDB=getReadableDatabase();
        Cursor cursor=ecommerceDB.rawQuery("select * from orders where custID = " + custID + " and address = '" + address + "' and ordDate = '" + ordDate + "'", null);
        if (cursor !=null)
            ((Cursor) cursor).moveToFirst();
        return cursor;
    }

    public Cursor getProductId(String proName)
    {
        ecommerceDB = getReadableDatabase();
        Cursor cursor = ecommerceDB.rawQuery("select * from products where proName like '" + proName + "' ",null);
        if(cursor.getCount()!=0)
        {
            cursor.moveToFirst();
            return  cursor;
        }
        return  cursor;
    }
/*
    public Cursor getCartDetails(String username)
    {
        ecommerceDB=getReadableDatabase();
        Cursor cursor = ecommerceDB.rawQuery("select * from card where username = '"+username+"'",null);
        if(cursor!= null)
        {
            cursor.moveToFirst();
        }
        return  cursor;
    }*/
/*
    public int getCatID(String catName)
    {

        ecommerceDB=getReadableDatabase();
        Cursor cursor = ecommerceDB.rawQuery("select catID from categories where catName = '" + catName + "'",null);
        if(cursor.getCount()!=0)
        {
            cursor.moveToFirst();
            return cursor.getInt(0);
        }
        return 0;
    }*/
}
