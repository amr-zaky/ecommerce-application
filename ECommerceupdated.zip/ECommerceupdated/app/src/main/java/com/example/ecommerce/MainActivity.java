package com.example.ecommerce;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Currency;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    DB customerDB;
    Integer id;
    /*private SharedPreferences myPrefs;
    private  static  final  String PREFS_NAME= "PrefsFile";*/
    private SharedPreferences loginPreferences;
    private SharedPreferences.Editor loginPrefsEditor;
    private Boolean saveLogin;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        customerDB = new DB(this);

        final EditText txtMail = (EditText)findViewById(R.id.txtMail);
        final EditText txtPassword = (EditText)findViewById(R.id.txtPassword);






        /* myPrefs=getSharedPreferences(PREFS_NAME,MODE_PRIVATE);*/
        loginPreferences = getSharedPreferences("loginPrefs", MODE_PRIVATE);
        loginPrefsEditor = loginPreferences.edit();
        final CheckBox chkRememberMe = (CheckBox)findViewById(R.id.chkRememberMe);

        saveLogin = loginPreferences.getBoolean("saveLogin", false);
        if (saveLogin == true) {
            txtMail.setText(loginPreferences.getString("username", ""));
            txtPassword.setText(loginPreferences.getString("password", ""));
            chkRememberMe.setChecked(true);
        }


        String username = txtMail.getText().toString();
        String password = txtPassword.getText().toString();


        Boolean log=false;
        try {
            log=getIntent().getExtras().getBoolean("logout");
        }
        catch (Exception e)
        {

        }
        if(customerDB.login(username, password) && log== false)
        {
            Toast.makeText(getApplicationContext(), "Successfully!", Toast.LENGTH_SHORT).show();
            Intent i = new Intent(MainActivity.this, homepage.class);
            id = customerDB.saveId(username, password);
            i.putExtra("CUSTID", id.toString());
            startActivity(i);
        }



        Button btnSignup = (Button)findViewById(R.id.btnSignup);
        btnSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, signup.class);
                startActivity(i);
            }
        });

        Button btnLogin = (Button)findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String username = txtMail.getText().toString();
                String password = txtPassword.getText().toString();

                if(chkRememberMe.isChecked())
                {
                    loginPrefsEditor.putBoolean("saveLogin", true);
                    loginPrefsEditor.putString("username", username);
                    loginPrefsEditor.putString("password", password);
                    loginPrefsEditor.commit();


                }

                else {
                    loginPrefsEditor.clear();
                    loginPrefsEditor.commit();
                }




                if(customerDB.login(username, password))
                {
                    Toast.makeText(getApplicationContext(), "Successfully!", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(MainActivity.this, homepage.class);
                    id = customerDB.saveId(username, password);
                    i.putExtra("CUSTID", id.toString());
                    startActivity(i);
                }

                else
                {
                    Toast.makeText(getApplicationContext(), "Username Or Password Invalid!", Toast.LENGTH_LONG).show();
                }

            }
        });

        TextView forgetPassword = (TextView)findViewById(R.id.forgetPassword) ;
        forgetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, forgetpassword.class);
                startActivity(i);
            }
        });


        /*chkRememberMe.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked == true)
                {
                    String m = txtMail.getText().toString();
                    String p = txtPassword.getText().toString();

                    txtMail.setText(m);
                    txtPassword.setText(p);
                }

                else
                {
                    txtMail.setText("");
                    txtPassword.setText("");
                }
            }
        });*/

        /*********************************************************************************************/

        /*ListView lst = (ListView)findViewById(R.id.lst);
        final ArrayAdapter<String> moviesAdapter=new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1);
        lst.setAdapter(moviesAdapter);
        Button btnRet = (Button)findViewById(R.id.btnRetrive);
        btnRet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                *//*Cursor cursor = customerDB.fetchAllOrders();
                moviesAdapter.clear();
                while(!((Cursor) cursor).isAfterLast())
                {
                    moviesAdapter.add(((Cursor) cursor).getString(2));
                    ((Cursor)cursor).moveToNext();
                }*//*
            }
        });*/
    }
}
