package com.example.ecommerce;

import android.app.DownloadManager;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class addprod extends AppCompatActivity {


        com.android.volley.RequestQueue q;
        StringRequest stringRequest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addprod);
        q=Volley.newRequestQueue(this);

        final EditText proname =(EditText)findViewById(R.id.proNameapi);
        final EditText quant=(EditText)findViewById(R.id.quantityapi);
        final EditText  price=(EditText)findViewById(R.id.priceapi);
        final EditText  catid=(EditText)findViewById(R.id.catIDapi);

        Button clicked=(Button)findViewById(R.id.dataadded);

        clicked.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                stringRequest = new StringRequest(
                        Request.Method.POST,
                        Appconfig.added_pro,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                try {
                                    //JSONObject obj=new JSONObject(response);
                                   // String s=obj.getString("message");
                                    //Toast.makeText(api.this,s, Toast.LENGTH_SHORT).show();

                                    //adapter.remove(delname);
                                    Toast.makeText(getApplicationContext(), "Product Added Succssfully", Toast.LENGTH_SHORT).show();
                                     Log.d("Tgggggggggggggg", response.toString());

                                     Intent ii=new Intent(getApplicationContext(),api.class);
                                     startActivity(ii);

                                }
                                catch (Exception e)
                                {
                                      Log.d("Errrrrrrrrrrrrrrrr", e.getMessage());
                                    Toast.makeText(getApplicationContext(), "Delete Error "+ e.getMessage(), Toast.LENGTH_LONG).show();
                                }
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Toast.makeText(getApplicationContext(),"delerorr"+error.getMessage(), Toast.LENGTH_LONG).show();
                            }
                        })
                { @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    //send your parameter here

                    Map<String, String> parameters = new HashMap<>();
                    parameters.put("proName",proname.getText().toString());
                    parameters.put("price",price.getText().toString());
                    parameters.put("quantity",quant.getText().toString());
                    parameters.put("catID",catid.getText().toString());
                    return parameters;
                }


                };



            q.add(stringRequest);



            }
        });


    }
}
