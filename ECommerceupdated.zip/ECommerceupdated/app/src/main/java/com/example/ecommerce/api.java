package com.example.ecommerce;

import android.app.DownloadManager;
import android.content.Intent;
import android.nfc.Tag;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class api extends AppCompatActivity {

    com.android.volley.RequestQueue q;
    String proName;
    Integer price;
    Integer quantity;
    Integer catID;
    Integer id;
    ListView mylist;
    String delname;
    String prid;
    ArrayAdapter<String> adapter;
    StringRequest stringRequest;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_api);

        q=Volley.newRequestQueue(this);


        stringRequest=new StringRequest(
                Request.Method.GET,
                Appconfig.add_pro,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                          mylist=(ListView)findViewById(R.id.apilist);
                          adapter=new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1);
                          mylist.setAdapter(adapter);

                          /*JSONObject obj=response;*/
                          /*JSONObject objc=new JSONObject(response);
                        JSONArray cp=objc.getJSONArray("products");*/

                       /*   JSONObject OB=new JSONObject(response);
                        for (int i=0;i<cp.length();i++)
                        {
                            JSONObject c=cp.getJSONObject(i);
                        }
                         */

                       try{
                        JSONObject obj=new JSONObject(response);
                        JSONArray cp=obj.getJSONArray("data");
                        for (int i=0;i<cp.length();i++)
                        {
                            try {

                                JSONObject c=cp.getJSONObject(i);
                                proName= c.getString("proName");
                              int  idd=c.getInt("proID");
                                adapter.add(idd + ": "+ proName);
                            }
                            catch (JSONException e)
                            {
                                Toast.makeText(api.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                       }
                       catch (JSONException ex)
                       {
                           Toast.makeText(api.this, ex.getMessage(), Toast.LENGTH_SHORT).show();
                       }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        );

        q.add(stringRequest);



        final ListView myslstt=(ListView)findViewById(R.id.apilist);
        final EditText test=(EditText)findViewById(R.id.testt);
        myslstt.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                delname=((TextView)view).getText().toString();
                prid=((TextView)view).getText().toString().split(": ")[0];

                test.setText(prid);

                Toast.makeText(api.this, "iddddddd" +prid , Toast.LENGTH_SHORT).show();
                stringRequest=new StringRequest(
                        Request.Method.POST,
                        Appconfig.del_pro,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                try {
                                    JSONObject obj=new JSONObject(response);
                                    String s=obj.getString("message");
                                    Toast.makeText(api.this,s, Toast.LENGTH_SHORT).show();

                                        adapter.remove(delname);
                                    Toast.makeText(api.this, "Product Deleted Succssfully", Toast.LENGTH_SHORT).show();
                                   // Log.d("Tagggggggggggggggggggggggggggggggggggggggg", response.toString());
                                }
                                catch (Exception e)
                                {
                                  //  Log.d("Erorrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr", e.getMessage());
                                    Toast.makeText(api.this, "Delete Error "+ e.getMessage(), Toast.LENGTH_LONG).show();
                                }
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Toast.makeText(api.this,"delerorr"+prid+error.getMessage(), Toast.LENGTH_LONG).show();
                            }
                        })
                { @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    //send your parameter here

                    Map<String, String> parameters = new HashMap<>();
                    parameters.put("proID",test.getText().toString());

                    return parameters;
                }


            };

                q.add(stringRequest);
                return false;
            }
        });


        Button addd=(Button)findViewById(R.id.addpro);

        addd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(),addprod.class);
                startActivity(i);
            }
        });

    }


}
