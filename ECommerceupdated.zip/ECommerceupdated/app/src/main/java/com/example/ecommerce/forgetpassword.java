package com.example.ecommerce;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class forgetpassword extends AppCompatActivity {
    DB customerDB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgetpassword);

        customerDB = new DB(this);
        final EditText txtForgetMail = (EditText)findViewById(R.id.txtForgetMail);
        final EditText txtForgetPassword = (EditText)findViewById(R.id.txtForgetPassword);
        final EditText txtYourJob = (EditText)findViewById(R.id.txtWhatsJob);

        Button btnForgetPassword = (Button)findViewById(R.id.btnForgetPassword);
        btnForgetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mail = txtForgetMail.getText().toString();
                String job = txtYourJob.getText().toString();
                Boolean answer = customerDB.whatsYourJob(mail, job);

                if(answer == true)
                {
                    Intent i = new Intent(forgetpassword.this, MainActivity.class);
                    String forgetPassword = txtForgetPassword.getText().toString();
                    customerDB.changePassword(mail, forgetPassword);
                    Toast.makeText(getApplicationContext(), "Password Has Changed Successfully!", Toast.LENGTH_SHORT).show();
                    startActivity(i);
                }

                else
                {
                    Toast.makeText(getApplicationContext(), "Wrong Answer - Try Again!", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}