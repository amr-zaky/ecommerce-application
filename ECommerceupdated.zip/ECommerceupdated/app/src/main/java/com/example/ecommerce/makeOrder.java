package com.example.ecommerce;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Date;
import java.text.SimpleDateFormat;

public class makeOrder extends AppCompatActivity {
    DB ecommerceDB;
    Integer xx, yy;
    Cursor c;
    Cursor c2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_make_order);

        ecommerceDB = new DB(this);

        final TextView proName = (TextView) findViewById(R.id.proNamee);
        final EditText proAddress = (EditText)findViewById(R.id.proAddress);
        final CalendarView calender = (CalendarView)findViewById(R.id.calender2);

        //final EditText proCustId = (EditText)findViewById(R.id.yourID);
        final EditText proQuantity = (EditText)findViewById(R.id.proQuantity);
        Button btnMakeOrder = (Button) findViewById(R.id.btnMakeOrder);


        proName.setText(getIntent().getExtras().getString("PRONAME"));
       final String proCustId=getIntent().getExtras().getString("custid");
        btnMakeOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String strdate = null;
                SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
                if (calender != null) {
                    strdate = sdf.format(calender.getDate());
                }
                Integer custID = Integer.parseInt(proCustId);
                long cursor = ecommerceDB.makeOrder(strdate, proAddress.getText().toString(), custID);
               // Toast.makeText(getApplicationContext(), "success1", Toast.LENGTH_SHORT).show();

                String address = proAddress.getText().toString();
                String qun=proQuantity.getText().toString();
                if( ! TextUtils.isEmpty(address) && ! TextUtils.isEmpty(qun))
                {
                    Cursor c = ecommerceDB.getOrderId(strdate, address, custID);
                    Integer orderID = Integer.parseInt(c.getString(0));
                    String productName = proName.getText().toString();
                    Cursor proID = ecommerceDB.getProductId(productName);
                    //  Toast.makeText(getApplicationContext(), "success2" + proID.getString(0) + " " + orderID.toString(), Toast.LENGTH_SHORT).show();

                    Integer Quantity = Integer.parseInt(proQuantity.getText().toString());
                    Integer productid = Integer.parseInt(proID.getString(0));
                    ecommerceDB.makeOrderDetails(orderID, productid, Quantity);
                    Toast.makeText(getApplicationContext(), "DONEEEEE", Toast.LENGTH_SHORT).show();
                }

                else
                {
                     Toast.makeText(getApplicationContext(), "Please Enter your location and Quantity", Toast.LENGTH_SHORT).show();
                }


            }
        });
    }
}
