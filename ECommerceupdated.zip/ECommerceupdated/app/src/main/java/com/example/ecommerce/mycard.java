package com.example.ecommerce;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class mycard extends AppCompatActivity {
    ArrayAdapter<String> adapter;


    DB custDB;
    String name;
    Integer custid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mycard);

        custDB = new DB(this);
        ListView lst = (ListView)findViewById(R.id.lstCart);
        adapter=new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1);

        lst.setAdapter(adapter);
        final Integer x = Integer.parseInt(getIntent().getExtras().getString("IDD"));
        custid=x;

      //  Toast.makeText(getApplicationContext(), x.toString(), Toast.LENGTH_SHORT).show();
        Cursor cursor = custDB.fetchAllOrders(x);

        adapter.clear();



        if(cursor == null)
            Toast.makeText(getApplicationContext(), "la2aa", Toast.LENGTH_SHORT).show();
        else
        {
            while(!(cursor).isAfterLast())
            {
                String productNames = cursor.getString(1);
                adapter.add(productNames);
                (cursor).moveToNext();
            }
        }

       /* lst.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                name = ((TextView)view).getText().toString();
                Toast.makeText(getApplicationContext(), name, Toast.LENGTH_SHORT).show();
            }
        });*/

       lst.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
           @Override
           public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
               name = ((TextView)view).getText().toString();
               return false;
           }
       });

        Button btnShowTotal = findViewById(R.id.btnShowTotal);
        btnShowTotal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor cursor2=custDB.fetchAllOrders(x);
                Integer total=0;
                if(cursor2 == null)
                    Toast.makeText(getApplicationContext(), "la2aa", Toast.LENGTH_SHORT).show();
                else
                {
                    while(!(cursor2).isAfterLast())
                    {
                        String price = cursor2.getString(2);
                        String quatitity = cursor2.getString(5);
                       total=total+(Integer.parseInt(price)*Integer.parseInt(quatitity));
                        //    total=total+Integer.parseInt(cursor2.getString())
                        (cursor2).moveToNext();
                    }
                }
                Toast.makeText(getApplicationContext(),"Total Price = "+total, Toast.LENGTH_SHORT).show();
            }
        });

        registerForContextMenu(lst);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = new MenuInflater(this);
        inflater.inflate(R.menu.quantity_menu, menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo)item.getMenuInfo();
        String selectedProduct = ((TextView)info.targetView).getText().toString();
        Cursor nn = custDB.getOrderID(name);
        String orid = nn.getString(0);
        Integer x = Integer.parseInt(orid);
        switch (item.getItemId())
        {
            case R.id.menUpdate:
                Intent i = new Intent(mycard.this, updatequantity.class);
                i.putExtra("orid", orid);
                i.putExtra("custid",custid);
                startActivity(i);
                return true;
            case R.id.menDelete:
                adapter.remove(selectedProduct);
                custDB.deleteOrder(x);
                return true;
        }
        return false;
    }
}

/*

android:background="@drawable/rb"*/
