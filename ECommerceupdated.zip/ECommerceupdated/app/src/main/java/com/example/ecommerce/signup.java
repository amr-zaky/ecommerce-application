package com.example.ecommerce;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import java.text.SimpleDateFormat;

public class signup extends AppCompatActivity {

    DB customerDB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        customerDB = new DB(this);

        final EditText txtName = (EditText)findViewById(R.id.txtCustName);
        final EditText txtMail = (EditText)findViewById(R.id.txtMail);
        final EditText txtPassword = (EditText)findViewById(R.id.txtPassword);
        final RadioButton rdMale = (RadioButton)findViewById(R.id.rdMale);
        final RadioButton rdFemale = (RadioButton)findViewById(R.id.rdFemale);
        final CalendarView calender = (CalendarView)findViewById(R.id.calender);
        final EditText txtJob = (EditText)findViewById(R.id.txtJob);

        Button btnRegister = (Button)findViewById(R.id.btnRegister);
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(txtName.getText().toString().equals("") || txtMail.getText().toString().equals("") || txtPassword.getText().toString().equals("") || txtJob.getText().toString().equals(""))
                {
                    Toast.makeText(getApplicationContext(), "Please Fill All Data!", Toast.LENGTH_LONG).show();
                }
                else
                {
                    String val = "";
                    if(rdMale.isChecked())
                        val = "Male";

                    else if(rdFemale.isChecked())
                        val = "Female";

                    String strdate = null;

                    SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

                    if (calender != null) {
                        strdate = sdf.format(calender.getDate());
                    }

                    long id = customerDB.createNewCustomer(txtName.getText().toString(), txtMail.getText().toString(),
                            txtPassword.getText().toString(), val, strdate, txtJob.getText().toString());
                    txtName.setText("");
                    txtMail.setText("");
                    txtPassword.setText("");
                    rdMale.clearFocus();
                    rdFemale.clearFocus();
                    txtJob.setText("");

                    Toast.makeText(getApplicationContext(), "Registered Successfully", Toast.LENGTH_LONG).show();
                    Intent i = new Intent(signup.this, MainActivity.class);
                    startActivity(i);
                }
            }
        });
    }
}
