package com.example.ecommerce;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class tab2 extends Fragment{
    EditText txtVoiceSearch;
    DB ecommerce;
    ListView lstVoiceSearch;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootview = inflater.inflate(R.layout.voice,container,false);
        ecommerce = new DB(getActivity());
        ImageButton btnVoiceSearch = rootview.findViewById(R.id.btnVoiceSearch);
        txtVoiceSearch = rootview.findViewById(R.id.txtVoiceSearch);
        lstVoiceSearch = rootview.findViewById(R.id.lstVoiceSearch);
        btnVoiceSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                startActivityForResult(i,200);
            }
        });
        return rootview;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==200)
        {
            if(resultCode==getActivity().RESULT_OK && data != null)
            {
                ArrayList<String> result=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                String x=result.get(0);
                Toast.makeText(getActivity(),x.toString(),Toast.LENGTH_LONG).show();

                txtVoiceSearch.setText(result.get(0));

                final ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1);
                lstVoiceSearch.setAdapter(adapter);
                Cursor cursor = ecommerce.searchInProducts(txtVoiceSearch.getText().toString());
                adapter.clear();

                while(!((Cursor) cursor).isAfterLast())
                {
                    adapter.add(cursor.getString(1));
                    cursor.moveToNext();
                }
            }
        }
    }
}
