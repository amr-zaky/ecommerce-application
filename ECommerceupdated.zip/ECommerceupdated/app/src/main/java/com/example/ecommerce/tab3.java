package com.example.ecommerce;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class tab3 extends Fragment{
    DB ecommerce;
    public static EditText txtCameraSearch;
    ListView lstCameraSearch;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.camera,container,false);

        ecommerce = new DB(getActivity());
        txtCameraSearch = rootView.findViewById(R.id.txtCameraSearch);
        lstCameraSearch = rootView.findViewById(R.id.lstCameraSearch);
        ImageButton btnCameraSearch = rootView.findViewById(R.id.btnCameraSearch);
        btnCameraSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(), barcode.class);
                startActivity(i);
            }
        });

        Button cl=(Button)rootView.findViewById(R.id.serchhhh);

        cl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String x=txtCameraSearch.getText().toString();
                Toast.makeText(getActivity(),x.toString(),Toast.LENGTH_LONG).show();
                    ListView lstVoiceSearch=(ListView)rootView.findViewById(R.id.lstCameraSearch);

                Cursor cursor=ecommerce.searchInProducts(x);

                final ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1);
                lstVoiceSearch.setAdapter(adapter);

                adapter.clear();

                while(!((Cursor) cursor).isAfterLast())
                {
                    adapter.add(cursor.getString(1));
                    cursor.moveToNext();
                }
            }
        });
        return rootView;
    }




    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1);
        lstCameraSearch.setAdapter(adapter);
        Cursor cursor = ecommerce.searchInProducts(txtCameraSearch.getText().toString());
        adapter.clear();

        while(!((Cursor) cursor).isAfterLast())
        {
            adapter.add(cursor.getString(1));
            cursor.moveToNext();
        }
    }
}
