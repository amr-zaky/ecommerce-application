package com.example.ecommerce;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class updatequantity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_updatequantity);

        final DB custDB = new DB(this);

        final String orderid = getIntent().getExtras().getString("orid");
        //final String custid = getIntent().getExtras().getString("custid");

       // Toast.makeText(getApplicationContext(), custid, Toast.LENGTH_SHORT).show();

        Cursor cursor = custDB.getQuantityForCurrentCustomer(Integer.parseInt(orderid));
        TextView text = findViewById(R.id.currentQuantity);
        text.setText(cursor.getString(0));
        final EditText txtUpdateQuantity = findViewById(R.id.txtUpdateQuantity);

        Button btnUpdateQuantity = findViewById(R.id.btnUpdateQuantity);
        btnUpdateQuantity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String newQuantity = txtUpdateQuantity.getText().toString();
                Integer newQ = Integer.parseInt(newQuantity);
                Integer or = Integer.parseInt(orderid);
                custDB.updateQuantity(newQ, or);
                Toast.makeText(getApplicationContext(), "Quantity-Changed Successfully!", Toast.LENGTH_SHORT).show();

            }
        });
    }
}
